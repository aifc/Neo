<li class="appointments_tab appointments_staff_tab advanced_options show_if_appointment"><a href="#appointments_staff"><?php _e( 'Staff', 'woocommerce-appointments' ); ?></a></li>
<li class="appointments_tab appointments_availability_tab advanced_options show_if_appointment"><a href="#appointments_availability"><?php _e( 'Availability', 'woocommerce-appointments' ); ?></a></li>
